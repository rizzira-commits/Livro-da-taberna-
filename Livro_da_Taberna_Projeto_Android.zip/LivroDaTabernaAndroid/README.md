# Livro da Taberna — Android

Projeto Android simples (Kotlin + WebView) com funcionamento offline.

## O que inclui
- Pedidos por mesa/cliente e baixa automática do estoque ao finalizar.
- Cadastro e exclusão de produtos.
- Entradas e saídas manuais de estoque.
- Caixa com vendas, despesas e saldo.
- Valores exclusivamente em **groschen**.
- Dados armazenados localmente no aparelho usando `localStorage`.

## Como gerar o APK
1. Instale o Android Studio em um computador Windows, macOS ou Linux.
2. Abra a pasta `LivroDaTabernaAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle e instale o Android SDK 35 quando solicitado.
4. No menu **Build**, escolha **Build Bundle(s) / APK(s) > Build APK(s)**.
5. O Android Studio mostrará a localização do APK gerado. Para instalar, transfira o APK para o Android e permita a instalação desta fonte quando solicitado.

## Observações
- Este pacote contém o projeto-fonte pronto para abrir e compilar no Android Studio; não é um APK já compilado.
- Os dados ficam no armazenamento local do aplicativo. Desinstalar o app ou limpar os dados pode apagá-los. Faça cópias de segurança antes de trocar de aparelho.
- O projeto não envia dados para servidores e não exige internet durante o uso.
